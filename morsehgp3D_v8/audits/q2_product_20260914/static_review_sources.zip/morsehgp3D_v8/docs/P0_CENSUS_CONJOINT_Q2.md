# Census q2 conjoint : partager les ancres avant leur éclatement

14 septembre 2026, onzième tranche ouverte après e3af11a7.
`exploration_v8_hors_registre`, `cpu_reference`, `quantized_u16_input_only`,
`implementation_v8_p0`, `not_claimed`. GCP non utilisé.

## Objet et décision

`Q2AnchorMode::SharedProduct` conserve les deux facteurs A et B d'un
rectangle WSPD au lieu de commencer immédiatement une recherche par
ancre. Il est réservé au census SharedBlocks. Individual reste le défaut.
Les deux ordres GlobalDfs et ComplementFirst restent comparables, avec
ou sans certificat frère. Le front, les candidates et les supports
complets demandés ne changent pas.

Le compte est commun à toutes les paires A×B sur le préfixe de témoins
déjà résolu. Pour une boîte Z, les
[extrema exacts H de l'auditeur A](../audits/P0_SOUS_RECTANGLES_ET_GROUPES.md#9-census-q2--des-extrema-exacts-pour-partager-les-recherches)
permettent trois actions : minimum strictement positif, créditer sa
population ; maximum non positif, résoudre cette population à zéro ;
sinon raffiner. La saturation à K rejette le sous-produit entier.
Une fin de parcours sous K permet son admission, mais la collecte des
intérieurs et de toute la coquille reste payée pour chacun des supports.

Les 96 octets de constantes préparées décrivent les quatre couples de
bornes A/B par coordonnée. Ils ne transportent aucun crédit ni témoin.
Les carrés et différences sont calculés en i64 après promotion ; les
centres doublés et carrés de différences des extrémités tiennent en u32.
Le minimum sur Z est atteint à une borne, tandis que le maximum peut
être au sommet intérieur de la parabole : ne pas tester seulement les
coins pour ce maximum. Les boîtes continues donnent des certificats
sûrs sur leurs sites ; une indécision n'est jamais un rejet.

## Continuation et reprise à une ancre

Une tâche garde A, B, compte, curseur, phase, B original et son échappement.
Global suit le DFS habituel. Complement reporte B original, pas le B
courant : ses ancêtres propres sont divisés avant toute consommation et
sa population est visitée dans la seconde phase, terminée à son escape.

Tant qu'A est un groupe, **aucun point de A n'est exclu**. Un autre point
de A peut être intérieur à la paire d'une ancre donnée. Quand A devient
singleton, la tâche existante reprend compte/curseur/phase sans nouvelle
racine. L'exclusion de cette seule ancre dans Complement ne retire qu'une
contribution connue nulle, qu'elle soit déjà résolue ou encore à visiter.
Un bloc crédité uniformément ne pouvait pas contenir cette ancre car
H(a,b,a)=0. La collecte finale ne change pas.

Pour une indécision, la première politique divise Z si sa diagonale est
strictement plus grande que celles de A et B ; sinon elle divise le plus
large des deux facteurs de requête, égalité vers A. Les deux enfants
héritent du même préfixe et du même compte. Cette politique est à mesurer,
pas un théorème d'optimalité. Le certificat frère reste limité aux
subdivisions B du chemin à ancre fixe : aucun crédit partiel du frère
ou certificat conjoint supplémentaire n'est ajouté dans cette tranche.

## Coûts et distribution future

`joint_work` sépare racines, tâches, divisions A/B/Z, bornes, mouvements
structurels, consommations, événements de crédit, reprises singleton
après crédit et masses rejetées/admises/transmises. Ces trois masses
partitionnent les candidates. `credited_pair_mass` est cumulatif par
événement et peut dépasser les candidates. La profondeur maximale
concerne la récursion conjointe, pas toute la pile ni son empreinte.

Les compteurs génériques conservent le travail de la phase à ancre fixe,
plus la collecte. En mode conjoint, `count_root_starts` vaut le nombre
de rectangles et `query_tasks` vaut les reprises singleton plus deux
fois les splits B génériques. `anchor_queries` reste la somme descriptive
des petits facteurs ; ce n'est plus le nombre de recherches démarrées.
Le schéma v4 expose ces différences sans requalifier les anciens reçus.

Un test conjoint paie douze couples de constantes contre six à ancre
fixe : ne pas comparer leurs nombres comme des instructions équivalentes.
Mesurer aussi tâches, propositions frère, structure, front, collecte,
capacités retenues et temps englobant. Aucun tableau de paires, de
témoins ou de frontières n'est ajouté ; les handles désignent le même
index immuable. La récursion actuelle est synchrone ; une future file
doit posséder sa continuation complète et ses tampons de sortie.

Le nombre de sous-produits peut encore croître presque au carré. Le
partage de préfixes ne démontre donc pas une borne globale. L'épreuve
reste n8k/16k/32k, particulièrement les amas, puis le coût de toute
la chaîne et non celui du seul composant. q3/q4, FULL et GPU restent ouverts.

## Qualification prévue

Deux gates nouvelles : bornes conjointes face à un oracle indépendant,
puis supports/clé/intérieurs/coquilles face au census scalaire exhaustif.
Fixtures de frontière, retrait erroné de tout A, crédit hérité, deux
phases, transformations et exceptions. La fixture A={(100,0,0),(100,4,0)},
B={(0,1,0),(0,2,0),(0,3,0)}, z=(50,2,0) vérifie le témoin uniforme
Hmin=2498 ; à K2 les profondeurs cross [1,2,3] et [3,2,1] laissent
deux admissions, perdues si z était compté deux fois après la reprise.
Les builds neufs v8_joint_20260914 et v8_joint_sanitize_20260914 sont
réservés à cette qualification. Aucun résultat exécuté n'est encore acquis.
