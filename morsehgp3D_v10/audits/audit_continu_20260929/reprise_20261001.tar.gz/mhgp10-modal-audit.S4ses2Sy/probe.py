"""OPEN read-only diagnostic of modal reference, not a native/G4 campaign.

Pinned real AST, equal covariance Gaussians. Exact derivative disproves
the claimed equivalence of EM and Euclidean gradient basins; numerical
ODE is corroboration only. Also exposes a converged saddle and clique
expansion at the modal regrouping step. No shared source modifications.
"""
import ast
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np
from scipy.integrate import solve_ivp
from scipy.special import logsumexp, ndtr
import scipy.spatial

BASE = Path('/workspaces/E-HGP/build/v10-tour-vers-points/banc2/plan_map')
PINS = {
    BASE/'bassins.py': 'db6631a9a87bc4152a93da675801e971fea459191f4cf832122b2f1ccec5e3f6',
    BASE/'map_ref.py': '48394ec96afa202c286ef2b58b126379b775f91cbc6c73bfee6abf66b30260c4',
    BASE/'test_bassins.py': '87a7ef8bf50919f46ee284c81f72c696e4e66938f37cfbbb32585fe4b200676e',
}
GUARDS = 0


def need(ok, why):
    global GUARDS
    GUARDS += 1
    if not ok:
        raise RuntimeError(why)


raw = {p:p.read_bytes() for p in PINS}
need(all(hashlib.sha256(b).hexdigest()==PINS[p] for p,b in raw.items()), 'pins before')
mnodes = [n for n in ast.parse(raw[BASE/'map_ref.py']).body
          if isinstance(n, ast.FunctionDef) and n.name=='logpdf']
need(len(mnodes)==1, 'actual Gaussian density function')
menv = dict(np=np, math=math, LOG2PI=math.log(2*math.pi))
exec(compile(ast.Module(body=mnodes,type_ignores=[]),'map_ref.py','exec'),menv)
names = {'_prepare','_centres','log_density','gradient','ascend','group_modes'}
bnodes = [n for n in ast.parse(raw[BASE/'bassins.py']).body
          if isinstance(n, ast.FunctionDef) and n.name in names]
need({n.name for n in bnodes}==names,'actual modal function inventory')
env = dict(np=np,math=math,logsumexp=logsumexp,ndtr=ndtr,need=need,
           map_ref=SimpleNamespace(logpdf=menv['logpdf']),
           MAX_ITER=20000,STEP_TOL=1e-10,MERGE_TOL=1e-4)
exec(compile(ast.Module(body=bnodes,type_ignores=[]),'bassins.py','exec'),env)
m = np.array([2.,2.,0.])
T = np.diag([1.,2.,1.])
components = [dict(kind='gauss',count=100,label=j,sub=j,mu=s*m,T=T.copy())
              for j,s in enumerate((-1,1))]

# Exact covariance-metric separatrix of modal EM: u=m^T P x=0.
# At z=(1/2,-2,0), Euclidean gradient is -Pz and leaves u=0.
# Formula grad log f = P(m tanh(u)-x), origin Hessian = -P+(Pm)(Pm)^T.
z = [F(1,2),F(-2),F(0)]
p = [F(1),F(1,4),F(1)]
mu = [F(2),F(2),F(0)]
u = sum(mu[i]*p[i]*z[i] for i in range(3))
du = -sum(mu[i]*p[i]*p[i]*z[i] for i in range(3))
need(u==0 and du==F(-3,4),'exact EM boundary is not Euclidean-flow invariant')

starts = np.array([[.51,-2.,0.],[-.51,2.,0.]])
em,steps,left = env['ascend'](components,starts)
need(left==0 and em[0,0]>1.9 and em[1,0]<-1.9,'actual EM positive/negative modal destinations')
ode_rows = []
for rtol,atol in ((1e-10,1e-12),(1e-12,1e-14)):
    destinations = []
    for x in starts:
        def vector(_t,y):
            return env['gradient'](components,y[None,:])[0]
        sol=solve_ivp(vector,(0.,60.),x,method='DOP853',rtol=rtol,atol=atol,dense_output=True)
        need(sol.success and sol.t[-1]==60.,'ODE reached end')
        end=sol.y[:,-1]
        destinations.append(end)
        need(float(np.max(np.abs(vector(60.,end))))<1e-9,'numerically stationary ODE endpoint')
        trace=sol.sol(np.linspace(0.,60.,101)).T
        density=env['log_density'](components,trace)
        need(bool((np.diff(density)>-1e-9).all()),'numerically nondecreasing density trace')
    destinations=np.array(destinations)
    need(destinations[0,0]<-1.9 and destinations[1,0]>1.9,'Euclidean flow modal sides opposite EM')
    ode_rows.append(dict(rtol=rtol,atol=atol,signs=np.sign(destinations[:,0]).astype(int).tolist(),
                         gradient_max=float(np.abs(env['gradient'](components,destinations)).max())))

# Stable point of the update is NOT necessarily a local maximum.
stationary,ss,sl = env['ascend'](components,np.zeros((1,3)))
need(sl==0 and int(ss[0])==1 and bool((stationary==0).all()),'actual saddle declared converged in one step')
lab,pos,gap=env['group_modes'](stationary)
need(len(pos)==1 and lab.tolist()==[0],'actual stationary saddle grouped as a mode')
P=np.diag([1.,.25,1.])
hessian=-P+np.outer(P@m,P@m)
eig=np.linalg.eigvalsh(hessian)
need(eig[0]<0 and eig[-1]>0,'mixed Hessian eigenvalues at origin')

# A single finite filament has a strictly isolated longitudinal maximum.
# Its transverse density is a strict Gaussian maximum, and along the
# segment f'(l) is proportional to phi((l+L/2)/s)-phi((l-L/2)/s).
L,s=3.,.18
ell=1e-3
fdiff=math.exp(-.5*((ell+L/2)/s)**2)-math.exp(-.5*((ell-L/2)/s)**2)
need(fdiff<0,'finite segment density is strictly decreasing for l>0')
fsecond=-L*math.exp(-.5*((L/2)/s)**2)/(s**3*math.sqrt(2*math.pi))
need(fsecond<0,'strict longitudinal maximum, however ill-conditioned')

# Capture REAL query_pairs output length without replacing geometric work.
OriginalTree=scipy.spatial.cKDTree
counts=[]
class RecordedTree:
    def __init__(self,*a,**kw):
        self.inner=OriginalTree(*a,**kw)
    def query_pairs(self,*a,**kw):
        out=self.inner.query_pairs(*a,**kw)
        counts.append((len(out),int(out.nbytes)))
        return out
    def __getattr__(self,k):
        return getattr(self.inner,k)
cliques=[]
for n in (256,512,1024):
    with patch.object(scipy.spatial,'cKDTree',RecordedTree):
        lab,pos,gap=env['group_modes'](np.zeros((n,3)))
    pairs,nbytes=counts[-1]
    need(pairs==n*(n-1)//2 and len(pos)==1 and bool((lab==0).all()),'full clique materialized for one mode')
    cliques.append(dict(n=n,pairs=pairs,pair_bytes=nbytes))
need(all(p.read_bytes()==b for p,b in raw.items()),'pins after')
print(json.dumps(dict(status='PASS_PRIVATE_MODAL_REFERENCE_COUNTERS',guards=GUARDS,
                     pins={str(p):h for p,h in PINS.items()},
                     exact_boundary=dict(u=str(u),derivative=str(du)),em_signs=[1,-1],
                     euclidean_ode=ode_rows,saddle=dict(steps=1,unconverged=0,hessian_signs=[-1,-1,1]),
                     finite_filament=dict(strict_maximum=True,negative_curvature=fsecond),
                     modal_regrouping_cliques=cliques,
                     scope='population model and actual Python AST; ODE corroboration not exact certificate; no FULL/native/GPU'),
                 sort_keys=True))
