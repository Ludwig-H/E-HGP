"""Bounded, read-only causal checks of five MAP v1 holes versus current v2.

No native/cloud process and no source/result writes. Extension metadata functions
are loaded by actual AST; neither the extension nor run_tvp is imported.
"""
import ast
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import types


def fail_process(*a, **k):
    raise RuntimeError('audit forbids any nested process')


subprocess.Popen = fail_process
os.system = fail_process
sys.dont_write_bytecode = True
B = Path('/workspaces/E-HGP/build/v10-tour-vers-points/banc2/plan_map')
PINS = {
    B / 'map_ref.py': '16e8f55dd9cf93341e5f473005d8b00054caa33ada4167b02a5b0835f49616d9',
    B / 'etendu_tvp.py': '3b7abb67b2fb3f875328368027046e1f5b7c8f4ed1ac6cadf47309337adad750',
    B / 'archive/map_ref_v1_48394ec9.py': '48394ec96afa202c286ef2b58b126379b775f91cbc6c73bfee6abf66b30260c4',
    B / 'melange_iid.py': '700480615d024997a3910c9ab000afa32a25dbf9c95aa9e73201769dd9cee4e6',
    B / 'dev_etendue_20261001.json': '415f7ea8a3b12ff316f7518b88ff4aa45d5c2d18060fbfc9aa32fecf0165fd3e',
    B / 'map_manifest.json': 'b0e50a7febccba7fd35d26ff8d68110a4b382fb96f977caf37718eb83f8d5fea',
}


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def need(ok, why):
    if not ok:
        raise RuntimeError(why)


need(all(sha(p) == h for p, h in PINS.items()), 'source drift before probe')
sys.path.insert(0, str(B))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


M = load('map_ref_v2_guard_probe', B / 'map_ref.py')
V = load('map_ref_v1_guard_probe', B / 'archive/map_ref_v1_48394ec9.py')
np = M.np
need(M.generator_sha256() == M.SCENES_SHA256, 'generator drift')


def refusal(fn, *a, **k):
    try:
        fn(*a, **k)
    except ValueError as e:
        return str(e)
    raise RuntimeError('expected refusal was not observed')


def capture(c):
    return {k: list(c[k]) if k == 'origin' else c[k] for k in
            ('sites_sha256', 'truth_sha256', 'scene_digest', 'step', 'origin', 'points')}


sp = dict(family='anisotropic', n=256, groups=3, level='medium', noise_fraction=0.0, seed=17)
good = M.replay(sp)
cert = M.certify(good)
honest = capture(cert)
baseline = M.map_labels(good, cert)
out = {}

# 1: exactly preserving coordinates does not authorize altered density parameters.
old = V.replay(sp)
old.components[0]['T'] *= 2
old.latents[0]['Z'] *= 0.5
oldcert = V.certify(old, honest, None, None, 'strict')
oldlabels = V.map_labels(old, oldcert)
bad = M.replay(sp)
bad.components[0]['T'] *= 2
bad.latents[0]['Z'] *= 0.5
why = refusal(M.certify, bad, honest, None, None, 'strict')
replay = M.replay
M.replay = lambda s: bad
try:
    guardoff = M.certify(bad, honest, None, None, 'strict')
finally:
    M.replay = replay
out['guard1'] = dict(v1_accepted=True, changed=int(np.count_nonzero(oldlabels != baseline)),
                     v2_refusal=why, guard_off_accepts=guardoff['params_sha256'] != cert['params_sha256'])

# 2: hierarchical sub-identities are bound separately from their parent labels.
hs = dict(family='hierarchical', n=500, groups=3, level='medium', noise_fraction=0.0, seed=17)
hgood = M.replay(hs)
hc = M.certify(hgood)
hlabels = M.map_labels(hgood, hc, 'sub')
h1 = V.replay(hs)
for c in h1.components:
    c['sub'] = 0
h1c = V.certify(h1)
h2 = M.replay(hs)
for c in h2.components:
    c['sub'] = 0
r2 = refusal(M.certify, h2)
M.replay = lambda s: h2
try:
    r2oracle = refusal(M.certify, h2)
finally:
    M.replay = replay
out['guard2'] = dict(v1_accepted=True,
                     changed=int(np.count_nonzero(V.map_labels(h1, h1c, 'sub') != hlabels)),
                     v2_refusal=r2, canonical_guard_off_refusal=r2oracle,
                     sub_capture_bound='sub_sha256' in M.certify(M.replay(hs),
                         dict(capture(hc), sub_sha256=hc['sub_sha256']))['bound'])

# 3: malformed arrays fail before generator/rebuild/coercion.
G, T = np.array(M.sites_of(good, cert)), np.array(M.truth_of(good, cert))
big, frac = G.astype(np.uint64) + (1 << 32), T + 0.25
V.certify(V.replay(sp), None, big, frac)
gen = M._generate
M._generate = fail_process
try:
    r3site = refusal(M.certify, M.replay(sp), None, big)
    r3truth = refusal(M.certify, M.replay(sp), None, None, frac)
finally:
    M._generate = gen
strict_sites, strict_labels = M.strict_sites, M.strict_labels
M.strict_sites = lambda a, what='': np.asarray(a, dtype=np.uint32)
M.strict_labels = lambda a, what, lo, hi: np.asarray(a, dtype=np.int64)
try:
    c3off = M.certify(M.replay(sp), None, big, frac)
finally:
    M.strict_sites, M.strict_labels = strict_sites, strict_labels
out['guard3'] = dict(v1_accepted=True, site_refusal=r3site, truth_refusal=r3truth,
                     before_generator=True, guard_off_accepts='sites' in c3off['bound'])

# 4: old alias ignored; ordinary mutation impossible; even forced replacement detected.
old = V.replay(sp)
oldcert = V.certify(old)
oldgood = V.map_labels(old, oldcert)
old._bound['G'] = old._bound['G'][::-1].copy()
oldchanges = int(np.count_nonzero(V.map_labels(old, oldcert) != oldgood))
good._bound = {'G': G[::-1].copy()}
need(np.array_equal(M.map_labels(good, cert), baseline), 'new path reads old mutable alias')
immutable = False
try:
    M.sites_of(good, cert).setflags(write=True)
except ValueError:
    immutable = True
owner = cert._owner()
store = dict(owner._Owner__store)
honeststore = store['G']
store['G'] = M._freeze(G[::-1], '<u4')
object.__setattr__(owner, '_Owner__store', types.MappingProxyType(store))
r4 = refusal(M.map_labels, good, cert)
check = M._Owner.check
M._Owner.check = lambda owner, c: None
try:
    offchanges = int(np.count_nonzero(M.map_labels(good, cert) != baseline))
finally:
    M._Owner.check = check
    store['G'] = honeststore
    object.__setattr__(owner, '_Owner__store', types.MappingProxyType(store))
out['guard4'] = dict(v1_changed=oldchanges, old_alias_ignored=True, immutable=immutable,
                     forced_replacement_refusal=r4, guard_off_changed=offchanges)

# 5: real extension metadata AST, no run_tvp import and no flag authority.
names = {'scene_key', 'map_enabled', 'sub_skipped', 'judged', 'manifest_entry', 'reader_problems', 'load_manifest'}
nodes = [n for n in ast.parse((B / 'etendu_tvp.py').read_text()).body
         if isinstance(n, ast.FunctionDef) and n.name in names]
need(len(nodes) == len(names), 'extension AST function missing')
ref = M.reference(sp, exact=False)
entry = dict(points=cert['points'], sites_sha256=cert['sites_sha256'], truth_sha256=cert['truth_sha256'],
             sub_sha256=cert['sub_sha256'], reference=cert['reference'], map={'base': ref['details']['base']})
plan = dict(map={'enabled': True, 'judge': ['base']})
desc = dict(kind='nat', spec=dict(sp, replicate=0))
key = '%s|%d|%d|%s|%g|0' % (sp['family'], sp['n'], sp['groups'], sp['level'], sp['noise_fraction'])
ns = dict(map_ref=M, melange_iid=M.melange_iid, os=os, json=json, need=M.need,
          sha256_file=lambda p: sha(Path(p)), MAP_RESOLUTIONS={'base': 'map', 'sub': 'mapsub'},
          _STATE={'manifest': {'scenes': {key: entry}}})
exec(compile(ast.Module(body=nodes, type_ignores=[]), 'real_etendu_AST', 'exec'), ns)
sd = dict(points=cert['points'], quantization={'sites_sha256':cert['sites_sha256'],
          'truth_sha256':cert['truth_sha256']}, checks={'map':{'map_bound_ok':1,'map_manifest_ok':1}},
          map_reference={'certificate':cert.as_dict(), 'resolutions':{'map':{'details':ref['details']['base']}}})
rows = [dict(resolution='base', group=str(i), m=str(c)) for i,c in ref['details']['base']['truth_sizes'] if i >= 0]
need(ns['reader_problems'](plan, 'probe', desc, rows, sd) == [], 'honest direct reader fails')
bad = copy.deepcopy(sd)
bad['map_reference']['resolutions']['map']['details']['labels_sha256'] = '0' * 64
r5labels = ns['reader_problems'](plan, 'probe', desc, rows, bad)
bad2 = copy.deepcopy(sd)
bad2['quantization']['sites_sha256'] = '0' * 64
r5sites = ns['reader_problems'](plan, 'probe', desc, rows, bad2)
need(r5labels and r5sites, 'flags still bypass direct reader')
oldplan = json.loads((B / 'dev_etendue_20261001.json').read_bytes())
planrefusal = refusal(ns['load_manifest'], oldplan, str(B/'dev_etendue_20261001.json'))
out['guard5'] = dict(honest_passes=True, flags_1_dont_bypass_labels=r5labels,
                     flags_1_dont_bypass_sites=r5sites, old_v1_plan_refusal=planrefusal)

# True-prior invariant: an iid component with no realized sample still has positive density/prior.
for seed in range(64):
    isp = dict(family='iidweights', n=128, groups=8, level='d4', noise_fraction=0.0, seed=seed)
    im = M.replay(isp)
    missing = [j for j,c in enumerate(im.components) if c['count'] == 0]
    if missing:
        ic = M.certify(im)
        j = missing[0]
        ids,scores = M.log_scores(im, np.array([im.components[j]['mu']]))
        out['iid_zero_realized_count'] = dict(spec=isp, missing_class=j, true_prior=im.components[j]['weight'],
            at_its_mean_float_winner=int(ids[int(scores.argmax(axis=1)[0])]),
            at_its_mean_own_score=float(scores[0,ids.index(j)]), exact_site_check=M.exact_check(im,ic))
        break
else:
    out['iid_zero_realized_count'] = 'not observed in bounded 64-seed check'

need(all(sha(p) == h for p,h in PINS.items()), 'source drift during probe')
print(json.dumps(dict(scope='RAM certification/metadata checks only; no native/cloud qualification',
                     pins={str(p):h for p,h in PINS.items()}, results=out), sort_keys=True))
