"""Read-only A/B recoupe of the twelve-scene extended DEV trial, not a qualification."""
import csv
from collections import defaultdict
from fractions import Fraction as F
import gzip
import hashlib
import json
from pathlib import Path

BASE = Path('/workspaces/E-HGP/build/v10-tour-vers-points/banc2/plan_map/essai')
PINS = {
    'essai_etendue.json': 'f1f79fef4f50da328ee580931a9e7b743fcd64dfeafaed87660cfac32ea8a8b6',
    'essai_etendue.map_manifest.json': '9f204d78e1183f26a3b5b2867dcf0525cd345342f0db4ad43f43deaad4f0e52c',
    'essai.blocks.csv.gz': '912c3335ac675ed3650c1bf1bdf88a75397d7c0bedd90f623bf98929c8918341',
    'essai.flat.csv.gz': 'd65ab890e0a55ac1eec8e36e8387db8005e2ce4268bcb18d500fac1f4702cef0',
    'recu_essai.json': 'ab91eb017d333d3a56ac075c9875b5d5cfcd06b512f061533ab715d8e98f81de',
}
GUARDS = 0


def need(ok, why):
    global GUARDS
    GUARDS += 1
    if not ok:
        raise RuntimeError(why)


def pinned():
    return all(hashlib.sha256((BASE / p).read_bytes()).hexdigest() == h for p, h in PINS.items())


need(pinned(), 'trial pins before')
receipt = json.loads((BASE / 'recu_essai.json').read_text())
plan = json.loads((BASE / 'essai_etendue.json').read_text())
manifest = json.loads((BASE / 'essai_etendue.map_manifest.json').read_text())
need(receipt['plan'] == PINS['essai_etendue.json'] and receipt['manifest'] == PINS['essai_etendue.map_manifest.json'],
     'receipt plan and manifest bound')
need(receipt['merged']['blocks'] == PINS['essai.blocks.csv.gz'] and receipt['merged']['flat'] == PINS['essai.flat.csv.gz'],
     'receipt actual merged bytes bound')
need(receipt['merge']['units'] == 12 and receipt['merge']['missing'] == 0 and not receipt['merge']['problems'],
     'reported exact twelve-unit trial inventory')
units = receipt['units']
need(len(units) == len(manifest['scenes']) == 12, 'twelve units and manifest scenes')
rows = defaultdict(dict)
total = 0
for r in csv.DictReader(gzip.open(BASE / 'essai.blocks.csv.gz', 'rt')):
    total += 1
    unit = r['unit']
    need(unit in units, 'actual row belongs to receipt unit')
    n, d, i, m, size = map(int, (r['iou_num'], r['iou_den'], r['inter'], r['m'], r['block']))
    need(n == i and d == m + size - i and m > 0 and d > 0 and 0 <= i <= min(m, size), 'integer IoU identity')
    need(int(r['points']) == units[unit]['points'] and int(r['k']) in (2, 3, 5, 10), 'point count and K')
    if r['resolution'] not in ('base', 'map') or r['source'] not in ('ceiling_def8', 'cover'):
        continue
    res = r['resolution']
    skey = '%s|%d|%d|%s|%g|%d' % (r['family'], int(r['n']), int(r['plan_groups']), r['level'],
                                  float(r['noise']), int(r['replicate']))
    ent = manifest['scenes'][skey]
    need(ent['sites_sha256'] == units[unit]['sites_sha256'] and ent['points'] == int(r['points']), 'manifest row binding')
    if res == 'map':
        need(int(r['group']) in ent['map']['base']['present'], 'MAP group belongs to pinned manifest')
    slot = rows[(int(r['k']), res, r['source'])]
    key = (unit, int(r['group']))
    need(key not in slot, 'unique per-group/source/K/res key')
    slot[key] = (F(n, d), m)
need(total == receipt['merge']['block_rows'] == 3500, 'actual merged row count')
summary = []
details = []
for k in (2, 3, 5, 10):
    for res in ('base', 'map'):
        A = rows[(k, res, 'ceiling_def8')]
        B = rows[(k, res, 'cover')]
        need(set(A) == set(B), 'paired A/B keys')
        need(len(A) == sum(u['groups'][res] for u in units.values()) == 58, 'all expected positive groups')
        need(all(A[q][1] == B[q][1] for q in A), 'same target mass A/B')
        summary.append(dict(k=k, resolution=res, groups=len(A),
                            A_exact=sum(v == 1 for v, _m in A.values()), B_exact=sum(v == 1 for v, _m in B.values()),
                            A_gt08=sum(v > F(4, 5) for v, _m in A.values()),
                            B_gt08=sum(v > F(4, 5) for v, _m in B.values()),
                            A_mean=float(sum((v for v, _m in A.values()), F(0)) / len(A)),
                            B_mean=float(sum((v for v, _m in B.values()), F(0)) / len(B)),
                            exact_lost=sum(A[q][0] == 1 and B[q][0] < 1 for q in A),
                            purified=sum(B[q][0] > A[q][0] for q in A)))
        if k == 5:
            for unit in sorted(units):
                keys = [q for q in A if q[0] == unit]
                need(len(keys) == units[unit]['groups'][res], 'per-unit target multiplicity')
                details.append(dict(unit=unit, resolution=res, groups=len(keys),
                                    A_exact=sum(A[q][0] == 1 for q in keys), B_exact=sum(B[q][0] == 1 for q in keys),
                                    A_mean=round(float(sum((A[q][0] for q in keys), F(0)) / len(keys)), 6),
                                    B_mean=round(float(sum((B[q][0] for q in keys), F(0)) / len(keys)), 6)))
need(pinned(), 'trial pins after')
print(json.dumps(dict(status='PASS_PRIVATE_TRIAL_AB_MAP_RECOUPE', guards=GUARDS, pins=PINS,
                     summary=summary, k5_details=details,
                     scope='DEV pointwise informed MAP at quantized representatives; five producer guards still open; '
                           'independent maxima not common-radius cut, native completeness or G4/GPU qualification'), sort_keys=True))
