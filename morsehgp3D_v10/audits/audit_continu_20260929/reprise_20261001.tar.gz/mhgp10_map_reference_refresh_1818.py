"""Replay the same small causal controls with current 18:18 source pins.

Read-only. The historical probe is immutable and hash guarded. The sole edits
to its in-memory text are three source pins. Source snapshots are preserved
privately in /tmp/mhgp10-map-refresh-1818/, never imported into the campaign.
No native/cloud command or shared write. Refuses later source drift.
"""
import hashlib
from pathlib import Path

historical = Path('/tmp/mhgp10_map_reference_counters_20261001.py')
raw = historical.read_bytes()
if hashlib.sha256(raw).hexdigest() != '2374db39d2356b053330d35a8cdceb450aa8007a3685e2e867986533b6eab867':
    raise RuntimeError('historical causal probe changed')
source = raw.decode()
replacements = {
    '35c7a8f55edf0d334e3c11d2c59cdc526484688c64bd992634faa5a11409633f':
    '48394ec96afa202c286ef2b58b126379b775f91cbc6c73bfee6abf66b30260c4',
    'ff59bf47b57c5069fb77c847ebc567aef84e622ec202d42a47bd9e15c5fcba84':
    '0cea76dc5333181864244ac2662f9ede02d4c365a53f1667c48ca95b72258ff6',
    'c1477ed1303cc7d80c122c0c2c89386f0c86efa4fe39f7543dd66ee4be562fea':
    '4c6bc1cc15eae604fdafafece6fb95c138360d0198410f91774e3cb063b24f44',
}
for old, new in replacements.items():
    if source.count(old) != 1:
        raise RuntimeError('unexpected historical probe pin layout')
    source = source.replace(old, new)
exec(compile(source, str(historical), 'exec'), {'__name__': '__main__'})
