#!/usr/bin/env python3
"""Private actual-AST global-prefix cancellation probe, no native FULL claim."""
import ast
from bisect import bisect_left, bisect_right
import decimal
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS

import numpy as np

SRC = Path('/workspaces/E-HGP/build/v10-tour-vers-points/regles2/vote_condense/code/vc_fast.py')
PIN = '1b8074e932106b62b6e64485504586c9461a7c27580f2e209637b96b26a159d1'
GUARDS = 0


def need(ok, msg):
    global GUARDS
    GUARDS += 1
    if not ok:
        raise RuntimeError(msg)


def sha(b):
    return hashlib.sha256(b).hexdigest()


b = SRC.read_bytes()
need(sha(b) == PIN, 'source pin before')
names = {'Condense', '_Groupes', '_poids_exact', '_compare_exact', 'router'}
t = ast.parse(b, filename=str(SRC))
body = [x for x in t.body if isinstance(x, (ast.ClassDef, ast.FunctionDef)) and x.name in names]
need({x.name for x in body} == names, 'actual definitions complete')
env = dict(np=np, Fraction=F, exiger=need, bisect_left=bisect_left, bisect_right=bisect_right,
           decimal=decimal, QUASI=1e-9, UNANIME=1-1e-12,
           DEC=decimal.Context(prec=60), INF=np.iinfo(np.int64).max)
exec(compile(ast.Module(body=body, type_ignores=[]), str(SRC), 'exec'), env)


def compact_star():
    # Actual Condense methods, constructor deliberately not run. The star is
    # abstract. rank0=1/4 for children; rank3=1e12 for root.
    c = env['Condense'].__new__(env['Condense'])
    c.tete = np.arange(4, dtype=np.int64)
    c.cl = np.arange(4, dtype=np.int64)
    c.grand = np.ones(4, dtype=bool)
    c.ga = np.arange(4, dtype=np.int64)
    c.naissance = np.array([3, 0, 0, 0], dtype=np.int64)
    c.l_parent, c.l_fin, c.l_prof = [-1, 0, 0, 0], [3, 1, 2, 3], [0, 1, 1, 1]
    c.l_nais = c.naissance.tolist()
    c._up = None
    return c


LEVELS = [F(1, 4), F(50_000_000_000), F(125_000_000_000), F(1_000_000_000_000)]
WEIGHTS = [1 / LEVELS[r] for r in (1, 2, 2)]
need(2 * WEIGHTS[0] > sum(WEIGHTS) and WEIGHTS[0] / sum(WEIGHTS) == F(5, 9),
     'independent exact W2 strict majority')


def run(n, target_first=False, prefix_node=1):
    need(n >= 1 and prefix_node in (0, 1), 'fixture parameters')
    target = 0 if target_first else n-1
    other = np.array([i for i in range(n) if i != target], dtype=np.int64)
    site = np.r_[other, [target]*3]
    node = np.r_[np.full(n-1, prefix_node, dtype=np.int64), [1, 2, 3]]
    rk = np.r_[np.zeros(n-1, dtype=np.int64), [1, 2, 2]]
    w = np.r_[np.full(n-1, 4.0), [float(x) for x in WEIGHTS]]
    tour = NS(n=n, n_rk=np.array([3, 0, 0, 0]), exact=lambda r: LEVELS[int(r)])
    cd = compact_star()
    V = {'site': site, 'noeud': node, 'rk': rk, 'w': w, 'genre': 'W', 'z': 2}
    G = env['_Groupes'](tour, cd, V)
    compte = dict(arrets_sans_majorite=0, sans_vote_admis=0, quasi_egalites=0,
                  quasi_non_certifiees=0)
    out, intervals, margins = env['router'](tour, cd, V, G,
                                            {'decision': 'maj', 'denom': 'sc'}, compte)
    lo, hi = G.s_off[target], G.s_off[target+1]
    need(hi-lo == 3 and G.g_cl[lo:hi] == [1, 2, 3], 'three target groups')
    local = [G.g_w_l[j] for j in range(lo, hi)]
    recovered = [G.g_cum_l[j+1] - G.g_cum_l[j] for j in range(lo, hi)]
    # Existing exact fallback oracle DOES know the correct result, but is only
    # called by router if the already damaged FLOAT majority is near a tie.
    sign, cert = env['_compare_exact'](tour, V, G, [(lo, lo+1)], [(lo, hi)])
    need(sign == 1 and cert is True, 'actual exact comparison confirms majority')
    need(local == [float(x) for x in WEIGHTS], 'local group weights still intact')
    need(all(x in (0, 1) for x in out), 'root or first child only')
    # In the prefix_node1 variant every incidence date is in its abstract
    # node life: children born at1/4, root born at1e12. Root-prefix is an
    # intentional algebraic-only wiring, NOT temporally valid.
    times_valid = prefix_node == 1 or n == 1
    if times_valid:
        need(all(LEVELS[int(r)] >= LEVELS[int(tour.n_rk[int(u)])] and
                 (int(u) == 0 or LEVELS[int(r)] < LEVELS[3]) for u, r in zip(node, rk)),
             'abstract face lives really valid')
    return {
        'n': n, 'prefix_points': n-1, 'target_site': target,
        'prefix_node': prefix_node, 'abstract_face_lives_valid': times_valid,
        'prefix_float': G.g_cum_l[lo],
        'local_group_weights_hex': [x.hex() for x in local],
        'recovered_group_weights_hex': [x.hex() for x in recovered],
        'fast_target_cluster': out[target], 'exact_target_cluster': 1,
        'counter': compte, 'global_prefix_only_disagreement': out[target] != 1,
        'target_margin': margins[target], 'groups': len(G.g_cl),
    }


cases = [run(1)]
cases += [run(n) for n in (8000, 16000, 16385, 32000)]
cases += [run(16385, target_first=True)]
cases += [run(16385, prefix_node=0)]
need([x['fast_target_cluster'] for x in cases] == [1, 1, 1, 0, 0, 1, 0],
     'expected exact causal target routes')
for x in cases:
    need(x['counter']['quasi_egalites'] == 0 and x['counter']['quasi_non_certifiees'] == 0,
         'no quasi alert even on disagreement')
need(cases[3]['prefix_float'] == 65536.0, 'expected cancellation boundary')
need(len(set(cases[3]['recovered_group_weights_hex'])) == 1, 'three equal damaged weights')
need(cases[3]['local_group_weights_hex'] != cases[3]['recovered_group_weights_hex'],
     'damage occurs after local grouping')
need(sha(SRC.read_bytes()) == PIN, 'source pin after')
print(json.dumps({'status': 'PASS', 'scope': 'actual AST; no native FULL cloud realization',
                  'source': str(SRC), 'source_sha256': PIN,
                  'exact_target_share': '5/9', 'cases': cases, 'guards': GUARDS},
                 sort_keys=True, separators=(',', ':')))
