#!/usr/bin/env python3
"""Private actual-AST date-margin probe; abstract forests, NOT native FULL clouds.

No source import, engine, Scene, binary, or cloud call. All selected sources are
hashed before AST compilation and again after the tiny RAM probes. QS and Rayon
are the actual pinned arithmetic definitions, not float/rational substitutes.
"""
import ast
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
from types import SimpleNamespace as NS

import numpy as np

ROOT = Path('/workspaces/E-HGP/build')
SOURCES = {
    'fast': (ROOT / 'v10-tour-vers-points/regles2/vote_condense/code/vc_fast.py',
             '1b8074e932106b62b6e64485504586c9461a7c27580f2e209637b96b26a159d1'),
    'exact': (ROOT / 'v10-tour-vers-points/regles2/vote_condense/code/vc_exact.py',
              'a3ac14032df2c22d16613de251ea0be9e5b87b575837002d55e0f730212a9bc5'),
    'qsqrt': (ROOT / 'v10-verrou-points/ancrage_marges/qsqrt.py',
              'a1d1ed969fa5afc7b9a7e1746e07d770da45c5f80e9c2c80e034ad358394984d'),
    'regles': (ROOT / 'v10-verrou-points/fixtures_cibles/lib/regles.py',
               '517957e4e48d0f5b8f6e129955c2fc63b0d23613fa472a990d788b7e8d18bfd6'),
}
GUARDS = 0


def need(ok, msg):
    global GUARDS
    GUARDS += 1
    if not ok:
        raise RuntimeError(msg)


def digest(b):
    return hashlib.sha256(b).hexdigest()


def pinned_bytes():
    out = {}
    for k, (p, pin) in SOURCES.items():
        b = p.read_bytes()
        need(digest(b) == pin, 'source pin: ' + k)
        out[k] = b
    return out


def selected(b, names, env, label):
    tree = ast.parse(b, filename=label)
    nodes = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))
             and n.name in names]
    need({n.name for n in nodes} == set(names), 'missing AST definitions ' + label)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), label, 'exec'), env)
    return env


before = pinned_bytes()
qe = {'__name__': 'private_qsqrt_snapshot'}
# Actual complete stdlib-only qsqrt module, no __main__ selftest invocation.
exec(compile(before['qsqrt'], str(SOURCES['qsqrt'][0]), 'exec'), qe)
QS = qe['QS']
re = selected(before['regles'], ['Rayon'], {
    'Fraction': F, 'QS': QS, 'sqrt': math.sqrt, 'controler': need,
    'signe_qs': lambda q: q.sign(), 'SR': type('UnusedSR', (), {}),
}, 'actual_Rayon_AST')
Rayon = re['Rayon']
ee = selected(before['exact'], ['marge'], {
    'Fraction': F, 'RG': NS(QS=QS), 'Rayon': Rayon,
    'SR': re['SR'], 'exiger': need,
}, 'actual_exact_marge_AST')
fe = selected(before['fast'], ['marge', 'Resultat'], {
    'np': np, 'math': math, 'Fraction': F, 'exiger': need,
}, 'actual_fast_marge_Resultat_AST')


def run_case(name, middle):
    levels = [F(1), *middle, F(64)]
    need(all(a < b for a, b in zip(levels, levels[1:])), name + ': exact strict order')
    parent = [1, 2, 3, -1]
    st = NS(alpha2=[F(1)], T=NS(birth=levels, parent=parent))
    ce = NS(naissance=levels, cl=list(range(4)))
    # A routing trace with winning share 2/3, hence mu=1/3, at root radius8.
    steps = [(3, 0, 2.0 / 3.0, 2, (F(2), F(3)))]
    rd, exact_owner = ee['marge'](st, ce, 0, F(1), 0, steps, F(12))
    need(rd is not None and rd.b2 == 16, name + ': exact date squared16')
    direct_owner = max(i for i, x in enumerate(levels) if x <= 16)
    need(exact_owner == direct_owner, name + ': independent exact ancestor oracle')
    tour = NS(n=1, val=np.array([float(x) for x in levels]),
              parent=np.array(parent), n_rk=np.arange(4), couv_rk=np.array([0]),
              pid=np.array([0]), d_rk=np.array([1, 2, 3, np.iinfo(np.int64).max]),
              exact=lambda r: levels[int(r)])
    cf = NS(cl=np.arange(4), a=np.zeros(4, dtype=np.int64))
    cs, ds, ns = [0], [0], [0]
    vals, nrec = fe['marge'](tour, cf, cs, ds, ns, [[(3, 1.0 / 3.0)]], 12.0)
    need(nrec == 1, name + ': one delayed date')
    # Actual constructor guards all accept the FLOAT-selected rank/owner.
    res = fe['Resultat'](tour, cf, name, 1, cs, ds, ns, {}, date_val=vals)
    emitted = res.dates_exactes()[0]
    physical = F(16)
    future_owner = levels[ns[0]] > physical
    wrong_date = emitted != physical
    return {
        'name': name, 'levels_exact': [str(x) for x in levels],
        'levels_binary64_hex': [float(x).hex() for x in levels],
        'intended_date_squared': '16', 'exact_owner': exact_owner,
        'fast_owner': ns[0], 'fast_rank': ds[0],
        'fast_date_val': vals[0], 'fast_dates_exactes': str(emitted),
        'future_exact_owner': future_owner, 'date_exactly_changed': wrong_date,
        'constructor_guards_accepted': True,
    }


d = F(1, 1 << 60)
cases = [run_case('two_future_collisions', [16 + d, 16 + 2 * d]),
         run_case('two_past_collisions', [16 - 2 * d, 16 - d]),
         run_case('mixed_collision', [16 - d, 16 + d]),
         run_case('exact_boundary_then_future', [F(16), 16 + d]),
         run_case('separated_control', [F(15), F(17)])]
need([x['exact_owner'] for x in cases] == [0, 2, 1, 1, 1], 'expected exact ancestors')
need([x['fast_owner'] for x in cases] == [2, 2, 2, 2, 1], 'expected fast ancestors')
need([x['future_exact_owner'] for x in cases] == [True, False, True, True, False],
     'causal owner differences')
need([x['date_exactly_changed'] for x in cases] == [True, True, True, True, False],
     'causal reported date differences')
after = pinned_bytes()
need(before == after, 'sources changed during probe')
print(json.dumps({'status': 'PASS', 'scope': 'actual AST; abstract forests; not native FULL geometry',
                  'sources': {k: {'path': str(p), 'sha256': pin} for k, (p, pin) in SOURCES.items()},
                  'cases': cases, 'guards': GUARDS}, sort_keys=True, separators=(',', ':')))
