#!/usr/bin/env python3
"""OPEN exact integer CC(tol) prototype; no SciPy/native/cloud.

Atomic dyadic grid cells are cliques. Quotient edges: tight point AABBs
certify yes/no; ambiguous pairs stream exact distances, stop at first edge.
DSU components NEVER replace atomic geometries by greedy representatives.
Only n<=12 reference oracle enumerates all pairs. Large isolated-cloud
fixtures use exact known labels and analytical old clique edge counts.
"""
from fractions import Fraction
import hashlib
import itertools
import json
from pathlib import Path

SOURCE = Path('/workspaces/E-HGP/build/v10-tour-vers-points/banc2/plan_map/bassins.py')
PIN = 'b69e8003497f69e90b3f8b3e0fc49b618bc7640485002a6bec61e0d20fd0b520'
GUARDS = 0


def need(ok, why):
    global GUARDS
    GUARDS += 1
    if not ok:
        raise RuntimeError(why)


def find(parent, v):
    while parent[v] != v:
        parent[v] = parent[parent[v]]
        v = parent[v]
    return v


def union(parent, a, b):
    a, b = find(parent, a), find(parent, b)
    if a == b:
        return False
    parent[max(a, b)] = min(a, b)
    return True


def dist2(a, b):
    return sum((a[j] - b[j])**2 for j in range(3))


def normal_partition(labels):
    parts = {}
    for p, lab in enumerate(labels):
        parts.setdefault(lab, []).append(p)
    return sorted(parts.values())


def brute(points, tol):
    need(len(points) <= 12, 'small reference only, no large pair enumeration')
    ds = list(range(len(points)))
    for i, j in itertools.combinations(range(len(points)), 2):
        if dist2(points[i], points[j]) <= tol**2:
            union(ds, i, j)
    return [find(ds, i) for i in range(len(points))]


def collapse(points, tol):
    n = len(points)
    need(n > 0 and type(tol) is int and tol > 0, 'positive integer fixture scale')
    need(all(len(p) == 3 and all(type(x) is int for x in p) for p in points), 'integer 3D inputs')
    # h = greatest dyadic <= tol/2, so tol/4<h<=tol/2.
    exponent = tol.bit_length() - 2
    h = Fraction(2**exponent) if exponent >= 0 else Fraction(1, 2**(-exponent))
    need(3*h*h < tol*tol, 'strict cell clique certificate')
    stats = dict(points=n, key_coordinates=3*n, sort_comparisons=0, bbox_coordinate_updates=3*n,
                 cell_clique_checks=0, cells=0, group_pairs=0, bbox_lower_tests=0, bbox_upper_tests=0,
                 certified_no_edge=0, certified_edge=0, ambiguous_group_pairs=0, point_pair_tests=0,
                 unions=0, internal_point_pairs_materialized=0)

    class Record:
        __slots__ = ('key', 'i')

        def __init__(self, key, i):
            self.key, self.i = key, i

        def __lt__(self, other):
            stats['sort_comparisons'] += 1
            return (self.key, self.i) < (other.key, other.i)

    def key(p):
        return tuple(x // (1 << exponent) if exponent >= 0 else x * (1 << -exponent) for x in p)

    records = [Record(key(p), i) for i, p in enumerate(points)]
    records.sort()
    groups, boxes, keys, cell_of = [], [], [], [None]*n
    for r in records:
        p = points[r.i]
        if not keys or keys[-1] != r.key:
            keys.append(r.key)
            groups.append([])
            boxes.append((list(p), list(p)))
        g = len(groups) - 1
        groups[g].append(r.i)
        cell_of[r.i] = g
        lo, hi = boxes[g]
        for j in range(3):
            lo[j] = min(lo[j], p[j])
            hi[j] = max(hi[j], p[j])
    C = stats['cells'] = len(groups)
    ds = list(range(C))
    for lo, hi in boxes:
        stats['cell_clique_checks'] += 1
        need(dist2(lo, hi) < tol*tol, 'actual tight box confirms cell clique')
    for a, b in itertools.combinations(range(C), 2):
        stats['group_pairs'] += 1
        stats['bbox_lower_tests'] += 1
        al, ah = boxes[a]
        bl, bh = boxes[b]
        lower2 = sum(max(0, al[j]-bh[j], bl[j]-ah[j])**2 for j in range(3))
        if lower2 > tol*tol:
            stats['certified_no_edge'] += 1
            continue
        stats['bbox_upper_tests'] += 1
        upper2 = sum(max(abs(al[j]-bh[j]), abs(ah[j]-bl[j]))**2 for j in range(3))
        if upper2 <= tol*tol:
            stats['certified_edge'] += 1
            edge = True
        else:
            stats['ambiguous_group_pairs'] += 1
            edge = False
            for i in groups[a]:
                for k in groups[b]:
                    stats['point_pair_tests'] += 1
                    if dist2(points[i], points[k]) <= tol*tol:
                        edge = True
                        break
                if edge:
                    break
        if edge:
            stats['unions'] += union(ds, a, b)
    roots = sorted({find(ds, g) for g in range(C)})
    rank = {r: j for j, r in enumerate(roots)}
    labels = [rank[find(ds, cell_of[i])] for i in range(n)]
    return labels, stats


def greedy_count(points, tol):
    representatives = []
    for p in points:
        if not any(dist2(p, q) <= tol**2 for q in representatives):
            representatives.append(p)
    return len(representatives)


need(hashlib.sha256(SOURCE.read_bytes()).hexdigest() == PIN, 'source pin before')
small_fixtures = [
    ('single-cell', [(0,0,0), (1,1,1), (2,2,2)], 16, 1),
    ('boundary-cell-clique', list(itertools.product((-1,1), repeat=3)), 16, 1),
    ('chain-not-clique', [(0,0,0), (7,0,0), (14,0,0)], 10, 1),
    ('distance-equals-tol', [(0,0,0), (10,0,0)], 10, 1),
    ('ambiguous-edge', [(0,0,0), (3,3,0), (8,11,0), (11,8,0)], 10, 1),
    ('ambiguous-no-edge', [(0,3,0), (3,0,0), (8,11,0), (11,8,0)], 10, 2),
    ('ambiguous-exact-boundary', [(0,0,0), (3,3,0), (9,11,0), (11,9,0)], 10, 1),
]
small = []
for name, points, tol, expected in small_fixtures:
    labels, stats = collapse(points, tol)
    need(normal_partition(labels) == normal_partition(brute(points, tol)), 'small independent all-pair oracle')
    need(len(set(labels)) == expected, 'fixture expected components')
    if name.startswith('ambiguous'):
        need(stats['ambiguous_group_pairs'] == 1, 'fallback positively exercised')
    if name == 'chain-not-clique':
        need(greedy_count(points, tol) == 2 and dist2(points[0], points[-1]) > tol**2,
             'greedy representative causal failure')
    small.append(dict(name=name, labels=labels, stats=stats))

large = []
for M in (1, 3):
    for n in (8000, 16000, 32000):
        # M isolated packets: each has all 8 corners of a side2 cube, repeated
        # as converged limits may coincide. Packet diameter sqrt12<tol/4=4.
        points = []
        for i in range(n):
            g, c = i % M, (i // M) % 8
            points.append((64*g + (-1 if c & 1 else 1),
                           -1 if c & 2 else 1, -1 if c & 4 else 1))
        labels, stats = collapse(points, 16)
        need(all(labels[i] == i % M for i in range(n)), 'large known exact packet partition')
        need(stats['cells'] == 8*M and stats['group_pairs'] == (8*M)*(8*M-1)//2,
             'bounded atomic group count and paid pair loop')
        need(stats['ambiguous_group_pairs'] == stats['point_pair_tests'] == 0,
             'large no clique edges materialized and no fallback')
        counts = [(n + M - 1 - g)//M for g in range(M)]
        analytical_edges = sum(c*(c-1)//2 for c in counts)
        large.append(dict(n=n, packets=M, stats=stats, label_validation_points=n,
                          old_clique_edges_ANALYTICAL_ONLY=analytical_edges))
need(hashlib.sha256(SOURCE.read_bytes()).hexdigest() == PIN, 'source pin after')
print(json.dumps(dict(scope='OPEN integer CC graph only; no SciPy float-contact identity, native/GPU or global bound',
                     source_sha256=PIN, guards=GUARDS, small=small, large=large), sort_keys=True))
