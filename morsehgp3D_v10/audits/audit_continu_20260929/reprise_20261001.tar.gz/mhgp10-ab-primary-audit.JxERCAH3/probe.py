"""Read-only integer/Fraction A/B recoupe of pinned DEV primary CSVs.

Best blocks are independent per group. Counts do not certify native catalogue
completeness, same-radius extraction, population models or holdout performance.
"""
from collections import defaultdict
import csv
from fractions import Fraction as F
import gzip
import hashlib
import json
from pathlib import Path

BASE=Path('/workspaces/E-HGP/build/v10-tour-vers-points/DIAGNOSTIC/fusion')
PINS={BASE/'tvpab1.blocks.csv.gz':'879e2705e0a22d78de8d6585bcdd1a9f67d87f89fc6a90b88e56df18631cd541',
      BASE/'tvpc2_ab.blocks.csv.gz':'c8df03fe31af3570f2d43daa8cbbeea8f6a113e53e794df047e230c156c68790'}
GUARDS=0


def need(ok,why):
    global GUARDS
    GUARDS+=1
    if not ok:
        raise RuntimeError(why)


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


need(all(digest(p)==h for p,h in PINS.items()),'CSV pins before')
R=defaultdict(dict)
for path in PINS:
    with gzip.open(path,'rt') as stream:
        for r in csv.DictReader(stream):
            if r['level'] not in ('medium','hard') or r['resolution']!='base':
                continue
            block,k,source=r['plan_block'],int(r['k']),r['source']
            if not ((block=='native' and k==5 and source in ('ceiling_def8','cover','core','cdelay[1]'))
                    or (block=='native_g20' and k==10 and source in ('core','cdelay[1]'))):
                continue
            key=(r['unit'],r['group'])
            ds=R[(block,k,source)]
            need(key not in ds,'repeated group/source key')
            n,d,i,m,size=map(int,(r['iou_num'],r['iou_den'],r['inter'],r['m'],r['block']))
            need(n==i and d==m+size-i and m>0 and d>0 and 0<=i<=min(m,size),'integer IoU identity')
            ds[key]=(F(n,d),r)
need(all(len(R[('native',5,s)])==2048 for s in ('ceiling_def8','cover','core','cdelay[1]')),
     'primary g8 complete 256x8 selected groups')
A=R[('native',5,'ceiling_def8')]
B=R[('native',5,'cover')]
need(set(A)==set(B),'paired A/B keys')


def summarize(rows):
    byscene=defaultdict(list)
    for (unit,g),(v,r) in rows.items():
        byscene[unit].append(v)
    need(len(byscene)==256 and all(len(v)==8 for v in byscene.values()),'scene/group multiplicities')
    return dict(groups=len(rows),scenes=len(byscene),exact=sum(v==1 for v,r in rows.values()),
                gt05=sum(v>F(1,2) for v,r in rows.values()),gt08=sum(v>F(4,5) for v,r in rows.values()),
                mean_iou=float(sum((v for v,r in rows.values()),F(0))/len(rows)),
                all8_exact=sum(all(v==1 for v in vs) for vs in byscene.values()),
                all8_gt08=sum(all(v>F(4,5) for v in vs) for vs in byscene.values()),
                no_exact=sum(all(v<1 for v in vs) for vs in byscene.values()))


means={}
for block,k in (('native',5),('native_g20',10)):
    C,D=R[(block,k,'core')],R[(block,k,'cdelay[1]')]
    need(set(C)==set(D) and bool(C),'paired hybrid date/core keys')
    diff=[(abs(C[key][0]-D[key][0]),key) for key in C]
    worst,key=max(diff)
    means[block]=dict(groups=len(C),different=sum(v>0 for v,_ in diff),
                      mean_cdelay_minus_core=float(sum((D[key][0]-C[key][0] for key in C),F(0))/len(C)),
                      max_iou_diff=str(worst),worst_unit=key[0],worst_group=key[1],
                      core=str(C[key][0]),cdelay=str(D[key][0]))
need(all(digest(p)==h for p,h in PINS.items()),'CSV pins after')
print(json.dumps(dict(status='PASS_PRIVATE_PRIMARY_GROUP_COUNTS',guards=GUARDS,
                     pins={str(p):h for p,h in PINS.items()},A=summarize(A),B=summarize(B),
                     loss_mean=float(sum((A[k][0]-B[k][0] for k in A),F(0))/len(A)),
                     purified=sum(B[k][0]>A[k][0] for k in A),
                     exact_lost=sum(A[k][0]==1 and B[k][0]<1 for k in A),
                     exact_gained=sum(A[k][0]<1 and B[k][0]==1 for k in A),
                     A_gt08_B_le05=sum(A[k][0]>F(4,5) and B[k][0]<=F(1,2) for k in A),
                     hybrid_vs_core=means,
                     scope='independent DEV maxima, no native completeness/cut/population/GPU proof'),sort_keys=True))
