"""Private, read-only causal checks of the actual MAP helper.

No native executable, campaign, cloud, source write, or raw coordinate output.
Reads pinned sources once, executes that exact source in RAM, and rechecks pins.
These are corruption controls, not evidence of wrong current scene parameters.
"""
import ast
import copy
import csv
import gzip
import hashlib
import json
from pathlib import Path
import sys
import types

import numpy as np

BASE = Path('/workspaces/E-HGP/build/v10-tour-vers-points')
MAP_PATH = BASE / 'banc2/plan_map/map_ref.py'
PINS = {
    MAP_PATH: '35c7a8f55edf0d334e3c11d2c59cdc526484688c64bd992634faa5a11409633f',
    BASE / 'banc2/plan_map/test_map_ref.py': 'c1477ed1303cc7d80c122c0c2c89386f0c86efa4fe39f7543dd66ee4be562fea',
    BASE / 'banc2/plan_map/etendu_tvp.py': 'ff59bf47b57c5069fb77c847ebc567aef84e622ec202d42a47bd9e15c5fcba84',
    BASE / 'code/run_tvp.py': '6eb658869fab5363f9310cb13362d4867a7fcd7ad3b361c521b03937e6dca704',
    BASE / 'code/vendor/bench/scenes.py': '61ea9abc511726c2a9ff1e066f7603d6bef195a7c5356a2d2048c28229608f00',
}


def need(ok, why):
    if not ok:
        raise RuntimeError(why)


raw_sources = {p: p.read_bytes() for p in PINS}
before = {str(p): hashlib.sha256(b).hexdigest() for p, b in raw_sources.items()}
need(all(before[str(p)] == h for p, h in PINS.items()), 'source pin changed before test')
M = types.ModuleType('private_pinned_map_reference')
M.__file__ = str(MAP_PATH)
exec(compile(raw_sources[MAP_PATH], str(MAP_PATH), 'exec'), M.__dict__)

spec = dict(family='anisotropic', n=256, groups=3, level='medium', noise_fraction=0.0, seed=17)
good = M.replay(spec)
cg = M.certify(good)
labels = M.map_labels(good, cg)
capture = {key: copy.deepcopy(cg[key]) for key in (
    'sites_sha256', 'truth_sha256', 'points', 'step', 'origin', 'scene_digest')}
bad = M.replay(spec)
bad.components[0]['T'] *= 2.0
bad.latents[0]['Z'] *= 0.5
cb = M.certify(bad, capture=capture, float_policy='strict')
wrong = M.map_labels(bad, cb)
changed = int(np.count_nonzero(labels != wrong))
need(M.rebuild(good)[0].tobytes() == M.rebuild(bad)[0].tobytes(), 'raw points not preserved')
need(cg['sites_sha256'] == cb['sites_sha256'] and cg['truth_sha256'] == cb['truth_sha256'],
     'sites or truth not preserved')
need(cg['params_sha256'] != cb['params_sha256'] and changed > 0, 'causal MAP effect absent')
compensation = dict(accepted=True, raw_equal=True, sites_equal=True, truth_equal=True,
                    params_different=True, map_changed=changed, honest_capture=True,
                    policy='strict', float64=cb['float64'], bound=cb['bound'],
                    good_map=M.labels_sha256(labels), bad_map=M.labels_sha256(wrong))

# Positive control: changing the parameter WITHOUT compensating its latent is refused.
control = M.replay(spec)
control.components[0]['T'] *= 2.0
try:
    M.certify(control, capture=capture, float_policy='strict')
except ValueError as e:
    parameter_only_refused = 'nuage reconstruit' in str(e)
else:
    parameter_only_refused = False
need(parameter_only_refused, 'positive refusal control absent')

hspec = dict(family='hierarchical', n=500, groups=3, level='medium', noise_fraction=0.0, seed=17)
hgood = M.replay(hspec)
hcg = M.certify(hgood)
glab = M.map_labels(hgood, hcg, 'sub')
hbad = M.replay(hspec)
for component in hbad.components:
    component['sub'] = 0
hcb = M.certify(hbad)
blab = M.map_labels(hbad, hcb, 'sub')
need(hcg['sites_sha256'] == hcb['sites_sha256'] and hcg['truth_sha256'] == hcb['truth_sha256'],
     'base identity not preserved')
need(hcg['sub_sha256'] != hcb['sub_sha256'] and np.count_nonzero(glab != blab) > 0,
     'sub identity counterexample absent')
sub_identity = dict(accepted=True, sites_equal=True, base_truth_equal=True,
                    sub_truth_different=True, map_changed=int(np.count_nonzero(glab != blab)),
                    classes_before=M.classes_of(hgood, 'sub')[0], classes_after=M.classes_of(hbad, 'sub')[0])

# These supplied arrays are NOT the certified words/labels; coercion hides the difference.
large_words = hgood._bound['G'].astype(np.uint64) + (1 << 32)
fractional_truth = hgood._bound['truth'].astype(np.float64) + 0.25
array_cert = M.certify(M.replay(hspec), sites=large_words, truth=fractional_truth)
noncanonical_arrays = dict(accepted=True, words_exceed_uint32=bool(np.any(large_words > (1 << 32) - 1)),
                           fractional_truth=bool(np.any(fractional_truth != np.floor(fractional_truth))),
                           bound=array_cert['bound'])
need(noncanonical_arrays['words_exceed_uint32'] and noncanonical_arrays['fractional_truth'],
     'array counterexample absent')

post = M.replay(spec)
cp = M.certify(post)
baseline = M.map_labels(post, cp)
post._bound['G'] = post._bound['G'][::-1].copy()
after_words = M.map_labels(post, cp)
post_words = dict(accepted=True, certificate_digest_matches=False,
                  exactly_reversed=bool(np.array_equal(after_words, baseline[::-1])),
                  map_changed=int(np.count_nonzero(after_words != baseline)))
need(cp['sites_sha256'] != M.sites_sha256(post._bound['G']) and post_words['exactly_reversed']
     and post_words['map_changed'] > 0, 'postcert word-order counterexample absent')

# The extension's reader trusts producer flags; the actual manifest/side label SHA
# is not compared again by check_unit. This uses a RAM copy of one real baseline
# unit, plus cloned MAP-resolution rows; it is NOT a native MAP receipt.
import run_tvp as R
plan = json.loads((BASE / 'selection/plans/dev_tour_points_sel.json').read_text())
plan['map'] = dict(enabled=True)
name = 'nat_spherical_n2000_hard_nu0_r0'
desc = dict(R.units_of(plan))[name]
source_dir = BASE / 'selection/results/tvpc1'
sd = json.loads((source_dir / 'side' / (name + '.json')).read_text())
rows = {}
for suffix in ('blocks', 'flat'):
    with gzip.open(source_dir / 'rows' / (name + '.' + suffix + '.csv.gz'), 'rt') as stream:
        rows[suffix] = list(csv.DictReader(stream))
E = types.ModuleType('private_pinned_extension')
E.__file__ = str(BASE / 'banc2/plan_map/etendu_tvp.py')
# Reuse the exact pinned MAP module instead of rereading a potentially changing file.
sys.modules['map_ref'] = M
exec(compile(raw_sources[BASE / 'banc2/plan_map/etendu_tvp.py'], E.__file__, 'exec'), E.__dict__)
key = E.scene_key(desc['spec'])
E._STATE['manifest'] = dict(scenes={key: dict(map={'base': dict(present=list(range(8)),
                                                             labels_sha256='1' * 64)})})
R.expected_groups = E.expected_groups
R.expected_inventory = E.expected_inventory
sd['groups']['map'] = list(range(8))
sd['checks']['map'] = dict(map_bound_ok=1, map_manifest_ok=1)
sd['map_reference'] = dict(resolutions={'map': dict(details=dict(labels_sha256='1' * 64))})
for suffix in ('blocks', 'flat'):
    copies = []
    for row in rows[suffix]:
        if row['resolution'] != 'base':
            continue
        new = dict(row, resolution='map')
        if suffix == 'flat':
            new['config'] += '|map'
        copies.append(new)
    rows[suffix].extend(copies)
positive, _excused = R.check_unit(plan, name, desc, rows['blocks'], rows['flat'], sd, 'abc')
need(not positive, 'RAM baseline extension fixture rejected: ' + repr(positive))
sd['map_reference']['resolutions']['map']['details']['labels_sha256'] = 'f' * 64
negative, _excused = R.check_unit(plan, name, desc, rows['blocks'], rows['flat'], sd, 'abc')
need(not negative, 'reader now independently checks MAP label SHA')
extension_reader = dict(positive_problems=positive, corrupted_label_sha_accepted=True,
                        negative_problems=negative, producer_flag_preserved=True,
                        scope='RAM baseline receipt copy plus synthetic MAP-resolution rows')

after = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in PINS}
need(before == after, 'source changed during tests')
print(json.dumps(dict(status='PASS_PRIVATE_MAP_CAUSAL_COUNTERS', pins=before,
                     compensation=compensation, parameter_only_refused=parameter_only_refused,
                     sub_identity=sub_identity, noncanonical_arrays=noncanonical_arrays,
                     postcert_word_order=post_words, extension_reader=extension_reader,
                     scope='RAM corruption controls; no actual native/G4 result declared wrong'), sort_keys=True))
