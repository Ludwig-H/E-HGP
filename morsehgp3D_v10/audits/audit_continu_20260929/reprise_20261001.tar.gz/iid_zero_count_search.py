"""64 seeds x 128 Gaussian points, RAM only: true iid prior versus realized count.
No writes, no nested process, no native/cloud calculation.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys


def need(ok, why):
    if not ok:
        raise RuntimeError(why)


def no_process(*a, **k):
    raise RuntimeError('nested process forbidden')


subprocess.Popen = no_process
os.system = no_process
sys.dont_write_bytecode = True
B = Path('/workspaces/E-HGP/build/v10-tour-vers-points/banc2/plan_map')
MP = B / 'map_ref.py'
PIN = '16e8f55dd9cf93341e5f473005d8b00054caa33ada4167b02a5b0835f49616d9'
need(hashlib.sha256(MP.read_bytes()).hexdigest() == PIN, 'source drift before')
sys.path.insert(0, str(B))
sp = importlib.util.spec_from_file_location('iid_zero_count_audit', MP)
M = importlib.util.module_from_spec(sp)
sp.loader.exec_module(M)
np = M.np
tried = zero_scenes = 0
found = None
for seed in range(64):
    spec = dict(family='iidweights', n=128, groups=8, level='d4', noise_fraction=0.0, seed=seed)
    model = M.replay(spec)
    tried += 1
    absent = [j for j,c in enumerate(model.components) if c['count'] == 0]
    if not absent:
        continue
    zero_scenes += 1
    cert = M.certify(model)
    actual = M.map_labels(model, cert)
    # Counterfactual ONLY in RAM: retain every positive true prior regardless of realized count.
    corrected = [dict(c, count=max(1, c['count'])) for c in M.components_of(model, cert)]
    ids, scores = M.scores_of_components(corrected, M.representatives(model, cert))
    proper = np.asarray(ids, dtype=np.int64)[scores.argmax(axis=1)]
    bad = np.flatnonzero(actual != proper)
    if len(bad):
        exact = M.exact_check(model, cert)
        need(exact['disagreements'] == len(bad) and exact['undecided'] == 0, 'counterfactual not confirmed exactly')
        found = dict(spec=spec, absent_components=absent, certificate_reference=cert['reference'],
                     disagreements=len(bad), indices=bad.tolist(),
                     current_labels=actual[bad].tolist(), true_prior_labels=proper[bad].tolist(), exact=exact)
        break
need(hashlib.sha256(MP.read_bytes()).hexdigest() == PIN, 'source drift during')
print(json.dumps(dict(map_ref_sha256=PIN, seeds_tried=tried, zero_count_scenes=zero_scenes,
                     witness=found, scope='bounded RAM Gaussian scores; no native/cloud'), sort_keys=True))
