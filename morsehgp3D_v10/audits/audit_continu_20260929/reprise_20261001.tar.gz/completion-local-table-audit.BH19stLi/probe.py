#!/usr/bin/env python3
"""OPEN source-causal tiny aggregator guards. No real benchmark replay.

Actual pinned AST cross/main helpers. RAM A/B reader only is mocked with
100 deterministic keys: scope is data-join logic, NOT filesystem parser.
CSV/inventory fixtures are real tiny private files. Outputs stay private.
No claims about corruption of real developer results.
"""
import argparse
import ast
import collections
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import sys

SOURCE = Path('/workspaces/E-HGP/build/v10-tour-vers-points/DIAGNOSTIC/table_completion_locale.py')
PIN = '17b455fd9ab84dee068cbb0b794710012f6b6edafbb98cda3eed47f8277c1cd8'
HERE = Path(__file__).parent
GUARDS = 0


def need(ok, why):
    global GUARDS
    GUARDS += 1
    if not ok:
        raise RuntimeError(why)


raw = SOURCE.read_bytes()
need(hashlib.sha256(raw).hexdigest() == PIN, 'source pin before')
names = {'fr', 'sha256_file', 'cross', 'main'}
nodes = [n for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef) and n.name in names]
need({n.name for n in nodes} == names, 'actual AST inventory')
variants = ('antichaine', 'par_coupe_rho1', 'par_coupe_rho2', 'global_rho1', 'engagee_rho1', 'engagee_rho2')
key = ('k', 'source', 'mcs_key', 'resolution', 'group')
good = [dict(k='5', source='cover', mcs_key='', resolution='base', group=str(g), iou='0.7')
        for g in range(100)]
first_bad = dict(good[0], iou='0.25')
local = [first_bad] + good
env = dict(argparse=argparse, collections=collections, csv=csv, hashlib=hashlib,
           json=json, math=math, os=os, sys=sys, VARIANTS=variants,
           LABELS={v: v for v in variants}, KEY=key, MACHINE_COLS=('scene_digest',),
           read_blocks=lambda directory, unit: local if directory == 'local' else good)
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(SOURCE), 'exec'), env)
joined = env['cross']('local', 'g4', ['u'])
need(len(local) == 101 and len(good) == 100 and local[0] != good[0], 'nonvacuous duplicate discrepancy')
need(joined['rows'] == joined['same'] == 100 and joined['different'] == joined['one_sided'] == 0,
     'duplicate overwritten before comparison')

mode = 'optimized' if sys.flags.optimize else 'normal'
results = []
inv = json.loads((HERE / 'inventory.json').read_text())
for stem in ('good', 'changed'):
    path = HERE / (stem + '.csv')
    actual_sha = env['sha256_file'](path)
    output = HERE / ('output_' + mode + '_' + stem)
    need(not output.exists(), 'do not overwrite prior attempt')
    argv = ['--local', 'local', '--g4', 'g4', '--completion', str(path),
            '--inventory', str(HERE / 'inventory.json'), '--units', 'u',
            '--out-dir', str(output), '--min-units', '1']
    code = env['main'](argv)
    result = json.loads((output / 'completion_familles_dures.json').read_text())
    need(code == 0 and result['status'] == 'CONFORME' and result['problems'] == [],
         'actual positive status with duplicated A/B source rows')
    if stem == 'good':
        need(actual_sha == inv['out_sha256'], 'positive control inventory hash agrees')
        need(result['summary']['K5|cover|antichaine'] == 0.7, 'positive control table value')
    else:
        need(actual_sha != inv['out_sha256'], 'inventory actually stale after CSV mutation')
        need(result['summary']['K5|cover|antichaine'] == 0.75, 'mutated score really exercised')
    results.append(dict(case=stem, code=code, status=result['status'], actual_sha256=actual_sha,
                        receipt_sha256=inv['out_sha256'], antichain=result['summary']['K5|cover|antichaine']))
need(hashlib.sha256(SOURCE.read_bytes()).hexdigest() == PIN, 'source pin after')
print(json.dumps(dict(scope='OPEN tiny synthetic AST main/cross; mocked A/B reader only; no real data claim',
                     source_sha256=PIN, guards=GUARDS, duplicate_cross=joined, cases=results), sort_keys=True))
