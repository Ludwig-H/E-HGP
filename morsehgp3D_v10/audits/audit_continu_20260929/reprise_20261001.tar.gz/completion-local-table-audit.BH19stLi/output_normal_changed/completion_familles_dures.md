Inventaire : 1 unites recalculees en local (lot `nat`, 8 groupes, n = 2 000, replicat 0, bruit 0 et 0,1) ; 6 lignes de completion ; plafond de tours atteint 0 fois ; dette residuelle 0. Statut de la completion : COMPLET.

Recoupe des lignes de blocs A et B, calcul local contre session G4 `tvpab1` : 1 unites, 100 lignes comparees, 100 identiques, 0 differentes, 0 cles d un seul cote (colonne `scene_digest` exclue : empreinte brute des flottants, propre a la machine ; 100 lignes identiques avec elle).

### Familles dures : mIoU par variante (moyenne des unites de la cellule)

| Famille | Niveau | K | Arbre | Unites | antichaine | par_coupe_rho1 | par_coupe_rho2 | global_rho1 | engagee_rho1 | engagee_rho2 | engagee rho 2 : P / R | antichaine : P / R |
| --- | --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| synthetic | hard | 5 | cover | 1 | 0,750 | 0,700 | 0,700 | 0,700 | 0,700 | 0,700 | 0,800 / 0,800 | 0,800 / 0,800 |

### Familles dures : resume par arbre et K (moyenne des unites, deux familles reunies)

| K | Arbre | Unites | antichaine | par_coupe_rho1 | par_coupe_rho2 | global_rho1 | engagee_rho1 | engagee_rho2 |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 5 | cover | 1 | 0,750 | 0,700 | 0,700 | 0,700 | 0,700 | 0,700 |
