"""ROOT replay with a new output prefix only; original fixtures are unchanged.

The first copied-fixture attempt remains failed: copying through patch added
line endings, correctly caught by its positive hash guard. This wrapper uses
the actual original fixture bytes and refuses overwriting prior ROOT output.
"""
import hashlib
from pathlib import Path

original = Path('/tmp/completion-local-table-audit.BH19stLi/probe.py')
raw = original.read_bytes()
if hashlib.sha256(raw).hexdigest() != '4e235ab61ab7a63510610c8f4828afe2a91b867684c8cc998abbf9419e5d10a8':
    raise RuntimeError('Original probe changed')
old, new = "('output_' + mode", "('output_root_' + mode"
text = raw.decode()
if text.count(old) != 1:
    raise RuntimeError('Unexpected output prefix')
text = text.replace(old, new)
exec(compile(text, str(original), 'exec'), {'__file__': str(original), '__name__': '__main__'})
