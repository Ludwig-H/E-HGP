"""Independent exact Gaussian-score witness on a certified 128-site iid scene.

No native/cloud process, no bytecode, no source/result writes. The component
means, priors and rational ln2 enclosure below are derived independently;
neither exact_map nor exact_check supplies the reference decision.
"""
from fractions import Fraction as F
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import subprocess
import sys


def no_process(*args, **kwargs):
    raise RuntimeError('nested process forbidden')


subprocess.Popen = no_process
os.system = no_process
sys.dont_write_bytecode = True
B = Path('/workspaces/E-HGP/build/v10-tour-vers-points/banc2/plan_map')
PINS = {
    B / 'map_ref.py': '16e8f55dd9cf93341e5f473005d8b00054caa33ada4167b02a5b0835f49616d9',
    B / 'melange_iid.py': '700480615d024997a3910c9ab000afa32a25dbf9c95aa9e73201769dd9cee4e6',
}
guards = 0


def need(ok, why):
    global guards
    guards += 1
    if not ok:
        raise RuntimeError(why)


def check_pins():
    for path, pin in PINS.items():
        need(hashlib.sha256(path.read_bytes()).hexdigest() == pin, 'pin ' + str(path))


check_pins()
sys.path.insert(0, str(B))
sp = importlib.util.spec_from_file_location('private_iid_exact_root', B / 'map_ref.py')
M = importlib.util.module_from_spec(sp)
sp.loader.exec_module(M)
spec = dict(family='iidweights', n=128, groups=8, level='d4', noise_fraction=0.0, seed=18)
model = M.replay(spec)
cert = M.certify(model)
G = M.sites_of(model, cert)
need(len(G) == 128 and cert['reference'] == 'exact_iid', 'actual certified iid scene')
need(model.components[7]['count'] == 0 and model.components[7]['weight'] == 1, 'absent but positive prior')
actual = M.map_labels(model, cert)
need(int(actual[62]) == 5, 'actual current label')
h = F(cert['step'])
origin = [F(x) for x in cert['origin']]
x = [origin[k] + h * int(G[62, k]) for k in range(3)]
means = [[F(4 * a) for a in v] for v in itertools.product(range(2), repeat=3)]
weights = [16, 8, 4, 2, 1, 1, 1, 1]
for j, c in enumerate(M.components_of(model, cert)):
    need(all(F(float(c['mu'][k])) == means[j][k] for k in range(3)), 'canonical means')
    need(c['weight'] == weights[j], 'canonical true prior')
    need(all(F(float(c['T'][a, b])) == int(a == b) for a in range(3) for b in range(3)), 'identity covariance')
# ln 2 = sum_{k>=1} 1/(k*2^k). Tail is positive and < 2^-N/(N+1).
N = 160
lo = sum((F(1, k * (1 << k)) for k in range(1, N + 1)), F(0))
hi = lo + F(1, (N + 1) * (1 << N))
bounds = []
for j in range(8):
    a = weights[j].bit_length() - 1
    need((1 << a) == weights[j], 'power-of-two prior')
    q = sum(((x[k] - means[j][k]) ** 2 for k in range(3)), F(0)) / 2
    bounds.append((a * lo - q, a * hi - q))
margin_lo = min(bounds[7][0] - bounds[j][1] for j in range(7))
need(margin_lo > 0, 'independent rational lower margin for component7')
check_pins()
print(json.dumps(dict(scope='certified iid sites; independent rational Gaussian decision; no native/cloud',
    source_pins={str(p): h for p, h in PINS.items()}, spec=spec, index=62,
    current_label=int(actual[62]), independently_certified_label=7,
    absent_component=7, true_prior='1/34', physical_representative=[str(t) for t in x],
    positive_margin_lower_bound=str(margin_lo), margin_lower_float=float(margin_lo),
    ln2_terms=N, guards=guards), sort_keys=True))
