"""Strict read-only local audit of vc1: archive hashes and plan-derived rows.

No native process, cloud call, source/result write, or raw-coordinate output.
Checks all manifest entries independently in tar and extracted local files.
The full row inventory is derived from the pinned TASK PLAN, not `faits`.
Also reports the existing collector's smaller, declared-success inventory.
"""
import ast
import collections
import copy
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import tarfile
import types

S = Path('/workspaces/.ehgp-sessions/v10.20261001.vc1')
R = S / 'results/extracted/results'
F = R / 'cmd/000_mvc_vc1/files'
B = Path('/workspaces/E-HGP/build/v10-tour-vers-points/mesure_vc')
IP = F / 'inventaire_20261001T183931.json'
TP = B / 'plans/vc1/taches_vc1.json'
RP = B / 'code/mvc_run.py'
VP = B / 'code_fige_1803/vc_mesure.py'
PINS = {
    S / 'receipt.json': '0336e7e4f54d8578fab65d9450219bb20b2ff23c9cae5a6aabebc111b3eaf21e',
    S / 'results/results.tar.gz': '9647daecde5846878f98f1650f2b80bec0ba2e18ddc48a5437e1c04ece8c32b8',
    R / 'MANIFEST.sha256': 'bb25e94b08eb7fd73170f73553f4bd1a1a30d29a07bf6859a3802ebd71c561b0',
    IP: 'c990bc1e15018f21b1bd6acf3d507b2966a1a0cd39554c90a50a2ef193531eac',
    TP: '013706480c4e333bf29f3d734ef3fe593a13a7e7ea9062907da2a4ac1213db44',
    RP: 'ca28da9f35bbf915a800a10862c852c116076e89a37bf173491a3a3e859fda44',
    VP: '5bf8e533bbbc0b416e5ad736efb8f8f2404b48e5193e6a435121cd725b7e481c',
}


def need(ok, why):
    if not ok:
        raise RuntimeError(why)


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


need(all(sha(p) == h for p, h in PINS.items()), 'pin drift before audit')
receipt = json.loads((S / 'receipt.json').read_bytes())
inv = json.loads(IP.read_bytes())
tasks = json.loads(TP.read_bytes())['taches']
manifest = {}
for line in (R / 'MANIFEST.sha256').read_text().splitlines():
    digest, name = line.split('  ', 1)
    path = PurePosixPath(name)
    need(len(digest) == 64 and not path.is_absolute() and '..' not in path.parts,
         'unsafe/malformed manifest path')
    name = str(path)
    need(name not in manifest, 'duplicate manifest path')
    manifest[name] = digest
need(len(manifest) == receipt['results_manifest_files'] == 1630, 'manifest count mismatch')
bad_local = []
for name, digest in manifest.items():
    p = R / name
    need(p.is_file() and not p.is_symlink(), 'missing or linked local result: ' + name)
    if sha(p) != digest:
        bad_local.append(name)
local_names = {str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}
need(local_names == set(manifest) | {'MANIFEST.sha256'}, 'local extras or missing result files')
bad_tar, tar_names = [], set()
with tarfile.open(S / 'results/results.tar.gz', 'r:gz') as archive:
    for member in archive:
        if member.isdir():
            continue
        need(member.isfile(), 'non-regular archive member')
        path = PurePosixPath(member.name)
        need(not path.is_absolute() and '..' not in path.parts and path.parts[0] == 'results',
             'unsafe archive member')
        name = str(PurePosixPath(*path.parts[1:]))
        need(name not in tar_names, 'duplicate archive member')
        tar_names.add(name)
        stream = archive.extractfile(member)
        h = hashlib.sha256()
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
        expected = PINS[R / 'MANIFEST.sha256'] if name == 'MANIFEST.sha256' else manifest.get(name)
        if h.hexdigest() != expected:
            bad_tar.append(name)
need(not bad_local and not bad_tar and tar_names == local_names, 'archive/extracted hash mismatch')
need(inv['taches_sha256'] == PINS[TP] and inv['taches'] == len(tasks) == 789, 'task plan binding mismatch')
names = [t['nom'] for t in tasks]
need(len(set(names)) == len(names) and set(names) == set(inv['inventaire']), 'closed task inventory mismatch')
def frozen_source(rel):
    return B / rel.replace('code_fige/', 'code_fige_1803/')


code_bad = [rel for rel, digest in inv['code'].items()
            if not frozen_source(rel).is_file() or sha(frozen_source(rel)) != digest]
need(not code_bad, 'received code differs from local frozen source')

# Execute only the real metadata inventory functions, never the campaign.
ns = dict(math=math)
for path, wanted in ((VP, {'mcs_valeurs'}), (RP, {'mcs_liste', 'attendus_etendue'})):
    tree = ast.parse(path.read_text(), str(path))
    nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in wanted]
    need(len(nodes) == len(wanted), 'inventory AST function missing')
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec'), ns)


def skip_a1(variant, mcs, k):
    # Exact published exclusion on this pinned finite variant domain.
    return variant.startswith('VC[couv,') and int(mcs) <= int(k)


ns['charger_modules'] = lambda: types.SimpleNamespace(a1_saute=skip_a1)
totals = collections.Counter()
errors = collections.Counter()
units_errors, missing_units, declared_missing, unexpected, guards_bad = {}, {}, {}, {}, []
excluded_a1 = 0
quality_bad, oracle_bad = [], []
numeric_columns = ('miou', 'obj_precision', 'obj_recall', 'obj_f1', 'pq', 'pts_precision', 'pts_recall',
                   'coverage', 'clusters', 'groups', 'over_seg', 'under_seg')
receipts = []
group_cases = collections.defaultdict(collections.Counter)
units_without_b = []
quasi_counts = collections.Counter()
for t in tasks:
    name, group = t['nom'], t['groupe']
    qp = F / group / 'recus' / (name + '.json')
    lp = F / group / 'lignes' / (name + '.csv.gz')
    need(qp.is_file() and lp.is_file(), 'missing receipt/rows: ' + name)
    q = json.loads(qp.read_bytes())
    receipts.append(q)
    need(q['unite'] == name and q['k'] == t['k'] and q['variantes'] == t['variantes'], 'unit identity mismatch')
    need(q['etat'] == inv['inventaire'][name]['etat'] == 'complet' and inv['inventaire'][name]['rc'] == 0,
         'unexpected terminal task state')
    for key, message in q['erreurs'].items():
        errors['deadline_not_launched' if message == 'non_lance_echeance' else
               'timeout' if message.startswith('delai') else 'exception'] += 1
    if q['erreurs']:
        units_errors[name] = dict(count=len(q['erreurs']), reasons=dict(collections.Counter(q['erreurs'].values())))
    for per_mcs in q.get('infos', {}).values():
        for info in per_mcs.values():
            if isinstance(info, dict):
                for key in ('quasi_egalites', 'quasi_non_certifiees', 'quasi_egalites_dates'):
                    quasi_counts[key] += info.get(key, 0)
    for key, value in q.get('controles', {}).items():
        if key.endswith('_egale_cover') or key.endswith('_egale_core'):
            totals['coherence_gates'] += 1
            if value != 1:
                guards_bad.append((name, key, value))
    with gzip.open(lp, 'rt') as f:
        rows = list(csv.DictReader(f))
    actual = collections.Counter()
    for row in rows:
        need(row['unite'] == name and int(row['k']) == t['k'] and int(row['n']) == q['points'], 'row unit identity mismatch')
        key = tuple(row.get(field, '') for field in ('source', 'forme', 'mcs_label', 'etage', 'z', 'eps_c', 'fill'))
        actual[key] += 1
        totals['rows'] += 1
        totals['stage_' + row['etage']] += 1
        try:
            value = float(row['valeur'])
            need(math.isfinite(value) and 0 <= value <= 1, 'value outside domain')
            if row['etage'] == 'C':
                need(all(math.isfinite(float(row[col])) for col in numeric_columns), 'nonfinite C score')
        except (ValueError, RuntimeError):
            quality_bad.append((name, key))
        if row['etage'] == 'O' and row['o_ok'] != '1':
            oracle_bad.append((name, key))
    need(all(count == 1 for count in actual.values()), 'duplicate result row')
    if not any(key[3] == 'B' for key in actual):
        units_without_b.append(name)
    if t['genre'] == 'a':
        mcs = ns['mcs_valeurs'](t['k'], q['points'])
        expected = {(src, '', label, stage, z, '', '') for src in ('cover', 'core') for label, _ in mcs
                    for stage, z in (('B', ''), ('O', ''), ('C', '1'), ('C', '2'))}
        expected |= {('hdbscan', '', label, stage, z, '', '') for label, _ in mcs
                     for stage, z in (('B', ''), ('O', ''), ('C', '1'))}
        for v in t['variantes']:
            expected |= {(v, 'a2', label, stage, z, '', '') for label, _ in mcs
                         for stage, z in (('B', ''), ('O', ''), ('C', '1'), ('C', '2'))}
            expected |= {(v, 'a1', label, 'C', '1', '', '') for label, size in mcs
                         if not skip_a1(v, size, t['k'])}
            excluded_a1 += sum(skip_a1(v, size, t['k']) for label, size in mcs)
        declared = {key for key in expected if key[0] not in q['erreurs']}
    else:
        need(q['opts'] == t['opts'], 'receipt options different from task plan')
        mcs = ns['mcs_liste'](t['opts'], t['k'], q['points'])
        need(q['mcs'] == [[label, size] for label, size in mcs], 'MCS plan mismatch')
        full = copy.deepcopy(q)
        full['variantes'] = t['variantes']
        full['faits'] = {src: [label for label, _ in mcs] for src in
                         ['cover', 'core', 'hdbscan', 'mreach'] + t['variantes']}
        expected = ns['attendus_etendue'](full)
        declared = ns['attendus_etendue'](q)
        excluded_a1 += sum(skip_a1(v, size, t['k']) for v in t['variantes'] for label, size in mcs)
    missing = expected - set(actual)
    extra = set(actual) - expected
    dm = declared - set(actual)
    totals['rows_expected_full_plan'] += len(expected)
    totals['rows_expected_declared_success'] += len(declared)
    group_cases[group]['B_cases_actual'] += sum(key[3] == 'B' for key in actual)
    group_cases[group]['B_cases_expected_full_plan'] += sum(key[3] == 'B' for key in expected)
    if missing:
        missing_units[name] = dict(rows=len(missing), stages=dict(collections.Counter(k[3] for k in missing)))
    if extra:
        unexpected[name] = len(extra)
    if dm:
        declared_missing[name] = len(dm)
need(not declared_missing and not unexpected and not guards_bad and not quality_bad and not oracle_bad,
     'existing declared-success gates have defects')
need({str(p.relative_to(F)) for p in F.rglob('*.json') if '/recus/' in str(p)} ==
     {t['groupe'] + '/recus/' + t['nom'] + '.json' for t in tasks}, 'extra unit receipts')
need(all(sha(p) == h for p, h in PINS.items()) and not any(sha(frozen_source(rel)) != digest for rel, digest in inv['code'].items()),
     'pin drift during audit')
print(json.dumps(dict(status='LOCAL_HASHES_AND_DECLARED_RESULTS_VALID_FULL_PLAN_PARTIAL',
                     result_manifest_files=len(manifest), archive_and_local_bad=0, code_files_verified=len(inv['code']),
                     task_count=len(tasks), task_groups=dict(collections.Counter(t['groupe'] for t in tasks)),
                     task_states=dict(collections.Counter(v['etat'] for v in inv['inventaire'].values())),
                     error_kinds=dict(errors), units_with_errors=units_errors, totals=dict(totals),
                     missing_full_plan=missing_units, declared_missing=declared_missing, unexpected=unexpected,
                     declared_a1_mcs_le_k_exclusions=excluded_a1, coherence_failures=guards_bad,
                     source_mcs_B_cases_by_group={k: dict(v) for k, v in group_cases.items()},
                     units_without_B=units_without_b, quasi_counts=dict(quasi_counts),
                     oracle_failures=len(oracle_bad), quality_value_failures=len(quality_bad),
                     pins={str(p): h for p, h in PINS.items()}, scope='local metadata/CSV/hash checks; no new geometric qualification'),
                 sort_keys=True))
