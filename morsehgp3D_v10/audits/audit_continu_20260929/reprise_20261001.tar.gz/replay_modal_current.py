"""Read-only replay after archive recovery, changing only the current source pin."""
import hashlib
from pathlib import Path

probe = Path(__file__).parent / 'mhgp10-modal-audit-r2.e2IzRDpi/probe.py'
raw = probe.read_bytes()
if hashlib.sha256(raw).hexdigest() != 'e68d93b79225738fd36ae94cd4e1eb4445190e93c6a81c3289a36a555023e4e6':
    raise RuntimeError('recovered probe SHA mismatch')
old = 'db6631a9a87bc4152a93da675801e971fea459191f4cf832122b2f1ccec5e3f6'
new = 'b69e8003497f69e90b3f8b3e0fc49b618bc7640485002a6bec61e0d20fd0b520'
code = raw.decode()
if code.count(old) != 1:
    raise RuntimeError('ambiguous pin replacement')
exec(compile(code.replace(old, new), str(probe), 'exec'), {'__file__': str(probe), '__name__': '__main__'})
