# ehgp.v11.worker_plan.v1
PLAN_PYTHON_PINNED=1
PLAN_DEFAULT_BUILD=1
PLAN_BUILD_TIMEOUT=600
PLAN_RESULTS_CAP=536870912
PLAN_BUILD_TARGETS=(mhgp11_points_export)
PLAN_COUNT=3
PLAN_NAME_0=unpack
PLAN_TIMEOUT_0=300
PLAN_ARGV_0=(python3 '{src}/morsehgp3D_v11/bench/points_unpack.py' --archive '{data}/bouts.tar' --out '{build}/bouts_data')
PLAN_NAME_1=gate
PLAN_TIMEOUT_1=900
PLAN_ARGV_1=(python3 '{src}/morsehgp3D_v11/bench/points_gate.py' --export '{build}/mhgp11_points_export' --work '{build}/gate' --out '{build}/gate.json' --mirror '{out}/gate.json' --seconds 300)
PLAN_NAME_2=bouts
PLAN_TIMEOUT_2=1700
PLAN_ARGV_2=(python3 '{src}/morsehgp3D_v11/bench/points_campaign.py' --mode lidar --data '{build}/bouts_data' --export '{build}/mhgp11_points_export' --gate '{build}/gate.json' --work '{build}/bouts' --out '{out}/lidar' --jobs 24 --native-workers 2 --roles bout)
