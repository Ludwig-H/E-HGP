# ehgp.v11.worker_plan.v1
PLAN_PYTHON_PINNED=1
PLAN_DEFAULT_BUILD=1
PLAN_BUILD_TIMEOUT=1500
PLAN_RESULTS_CAP=134217728
PLAN_BUILD_TARGETS=(mhgp11_points_export)
PLAN_COUNT=3
PLAN_NAME_0=gate
PLAN_TIMEOUT_0=600
PLAN_ARGV_0=(python3 '{src}/morsehgp3D_v11/bench/points_gate.py' --export '{build}/mhgp11_points_export' --work '{build}/gate' --out '{build}/gate.json' --mirror '{out}/gate.json' --seconds 240)
PLAN_NAME_1=synthetic
PLAN_TIMEOUT_1=1200
PLAN_ARGV_1=(python3 '{src}/morsehgp3D_v11/bench/points_campaign.py' --mode synthetic --export '{build}/mhgp11_points_export' --gate '{build}/gate.json' --work '{build}/synth' --out '{out}/synthetic' --jobs 24 --native-workers 2)
PLAN_NAME_2=lidar
PLAN_TIMEOUT_2=2400
PLAN_ARGV_2=(python3 '{src}/morsehgp3D_v11/bench/points_campaign.py' --mode lidar --data '{data}' --export '{build}/mhgp11_points_export' --gate '{build}/gate.json' --work '{build}/lidar' --out '{out}/lidar' --jobs 20 --native-workers 4 --roles demo,echec)
