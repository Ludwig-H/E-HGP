# ehgp.v11.worker_plan.v1
PLAN_PYTHON_PINNED=0
PLAN_DEFAULT_BUILD=0
PLAN_BUILD_TIMEOUT=600
PLAN_RESULTS_CAP=16777216
PLAN_BUILD_TARGETS=()
PLAN_COUNT=1
PLAN_NAME_0=prepare-python-host
PLAN_TIMEOUT_0=600
PLAN_ARGV_0=(python3 '{src}/morsehgp3D_v11/receipts/full_points_20261003/experiment/prepare_python_host.py' --out '{out}/host' --zone us-central1-c --instance ehgp-v7-3b1d496aed430749ea7e049f --install-missing)
