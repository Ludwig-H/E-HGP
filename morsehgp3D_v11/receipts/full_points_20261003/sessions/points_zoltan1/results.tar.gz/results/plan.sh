# ehgp.v11.worker_plan.v1
PLAN_PYTHON_PINNED=1
PLAN_DEFAULT_BUILD=0
PLAN_BUILD_TIMEOUT=600
PLAN_RESULTS_CAP=134217728
PLAN_BUILD_TARGETS=()
PLAN_COUNT=3
PLAN_NAME_0=build-probe
PLAN_TIMEOUT_0=300
PLAN_ARGV_0=(python3 '{src}/morsehgp3D_v11/receipts/full_points_20261003/experiment/build_probe.py' --source '{src}' --build '{build}/points-build' --out '{out}/build')
PLAN_NAME_1=native-gate
PLAN_TIMEOUT_1=150
PLAN_ARGV_1=(python3 '{src}/morsehgp3D_v11/receipts/full_points_20261003/experiment/native_gate.py' --probe '{build}/points-build/points_probe' --work '{build}/gate' --out '{out}/native_gate.json' --quick)
PLAN_NAME_2=zoltan
PLAN_TIMEOUT_2=1050
PLAN_ARGV_2=(python3 '{src}/morsehgp3D_v11/receipts/full_points_20261003/experiment/run_experiment.py' --probe '{build}/points-build/points_probe' --work '{build}/campaign' --out '{out}/campaign' --mode zoltan --data '{data}' --gate '{build}/gate/gate.json')
