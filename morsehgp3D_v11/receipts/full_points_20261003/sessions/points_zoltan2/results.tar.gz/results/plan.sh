# ehgp.v11.worker_plan.v1
PLAN_PYTHON_PINNED=1
PLAN_DEFAULT_BUILD=0
PLAN_BUILD_TIMEOUT=600
PLAN_RESULTS_CAP=134217728
PLAN_BUILD_TARGETS=()
PLAN_COUNT=3
PLAN_NAME_0=restore-frozen-probe
PLAN_TIMEOUT_0=30
PLAN_ARGV_0=(python3 '{src}/morsehgp3D_v11/receipts/full_points_20261003/experiment/restore_frozen_probe.py' --binary '{data}/points_probe.c40' --manifest '{data}/points_probe.c40.build.json' --build '{build}/points-build' --out '{out}/restore')
PLAN_NAME_1=native-gate
PLAN_TIMEOUT_1=150
PLAN_ARGV_1=(python3 '{src}/morsehgp3D_v11/receipts/full_points_20261003/experiment/native_gate.py' --probe '{build}/points-build/points_probe' --work '{build}/gate' --out '{out}/native_gate.json' --quick)
PLAN_NAME_2=zoltan-resume
PLAN_TIMEOUT_2=1300
PLAN_ARGV_2=(python3 '{src}/morsehgp3D_v11/receipts/full_points_20261003/experiment/run_experiment.py' --probe '{build}/points-build/points_probe' --work '{build}/campaign' --out '{out}/campaign' --mode zoltan --data '{data}' --gate '{build}/gate/gate.json' --case zoltan_04_velos_en_rang_avec_sol --case zoltan_05_temoin_voitures_en_file)
